<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly?>
<?php get_header(); ?>
<div class="this_page oi_page_holder">
	<div class="oi_sinle_portfolio_holder">
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
       <div class="container-portfolio">
       
        <div class="oi_portfolio_page_holder">
			<?php do_shortcode(the_content());?>
        </div>
        </div>
        <div class="port_navi">
        	<?php
			$next_post = get_next_post();
			$previous_post = get_previous_post();
			if(isset($previous_post->ID)){
			$prev_image = wp_get_attachment_url( get_post_thumbnail_id($previous_post->ID,''));
			}
			if(isset($next_post->ID)){
			$next_image = wp_get_attachment_url( get_post_thumbnail_id($next_post->ID,''));
			}
			?>
        <div class="oi_port_nav oi_main_port_nav">
        	<div class="raw">
            	<?php if (isset($next_post->ID)){?>
                <div class="<?php if (isset($previous_post->ID)){?>col-md-5 col-sm-5 col-xs-5<?php }else{echo 'col-md-12';};?> oi_np_holder" style=" background-image:url('<?php echo $next_image; ?>');">
                    <span class="oi_np_link"><?php next_post_link('%link','<span class="oi_a_holder" data-id="'.$next_post->ID.'"><i class="fa fa-long-arrow-left fa-fw"></i> <span class="np_t">%title</span></span>', false); ?></span>
                </div>
                <?php };?>
                <div class="col-md-2 col-sm-2"></div>
                <?php if (isset($previous_post->ID)){?>
                <div class="<?php if (isset($next_post->ID)){?>col-md-5 col-sm-5 col-xs-5<?php }else{echo 'col-md-12';};?> oi_np_holder" style="background-image:url('<?php echo $prev_image; ?>');">
                	<span class="oi_np_link"><?php  previous_post_link('%link','<span class="oi_a_holder" data-id="'.$previous_post->ID.'"><span class="np_t">%title</span> <i class="fa fa-long-arrow-right fa-fw"></i></span>', false); ?></span>
                </div>
                <?php };?>
            </div>
        </div>
        </div>
		
   	
   	<?php endwhile; endif;?>
    </div>
</div>
<div class="clearfix"></div>
<?php get_footer(); ?>