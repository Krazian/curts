<?php

add_shortcode('vc_clock', 'vc_clock_f');
function vc_clock_f( $atts, $content = null)
{
	extract(shortcode_atts(
		array(
			'height' => 'x1',
			'contact' => '',
			'title' => '',
		), $atts)
	);
	$output ='<div class="oi_vc_text oi_vc_clock text-center item_height_x1">
	<div class="oi_clock_mask_holder">
		<a href="#"  data-remodal-target="clock"><div class="oi_clock_mask">'.$contact.'</div></a>
	</div>
	<div class="oi_vc_text_span text-center">
		<div class="app">

			<div class="clock">

				<div class="clock-inner">

					<div class="clock-center"></div>
					<div id="clock-seconds"></div>
					<div id="clock-minutes"></div>
					<div id="clock-hours"></div>

					<ul class="clock-numbers">

						<li>12</li>
						<li>3</li>
						<li>6</li>
						<li>9</li>

					</ul>

				</div> <!-- end clock-inner -->

			</div> <!-- end clock -->
		</div> <!-- end app -->
	</div>
</div>

<!-- Modal -->
<div class="remodal" style="" data-remodal-id="clock">
				  <button data-remodal-action="close" class="remodal-close"></button>
				  '.do_shortcode($content).'
				</div>
<script>
jQuery.noConflict()(function($){
(function() {

	var clockSeconds = document.getElementById("clock-seconds"),
	clockMinutes = document.getElementById("clock-minutes"),
	clockHours = document.getElementById("clock-hours");

	function getTime() {

		var date = new Date(),
		seconds = date.getSeconds(),
		minutes = date.getMinutes(),
		hours = date.getHours(),

		degSeconds = seconds * 360 / 60,
		degMinutes = (minutes + seconds / 60) * 360 / 60,
		degHours = (hours + minutes / 60 + seconds / 60 / 60) * 360 / 12;

		clockSeconds.setAttribute("style", "-webkit-transform: rotate(" + degSeconds + "deg); -moz-transform: rotate(" + degSeconds + "deg); -ms-transform: rotate(" + degSeconds + "deg); -o-transform: rotate(" + degSeconds + "deg); transform: rotate(" + degSeconds + "deg);");
		clockMinutes.setAttribute("style", "-webkit-transform: rotate(" + degMinutes + "deg); -moz-transform: rotate(" + degMinutes + "deg); -ms-transform: rotate(" + degMinutes + "deg); -o-transform: rotate(" + degMinutes + "deg); transform: rotate(" + degMinutes + "deg);");
		clockHours.setAttribute("style", "-webkit-transform: rotate(" + degHours + "deg); -moz-transform: rotate(" + degHours + "deg); -ms-transform: rotate(" + degHours + "deg); -o-transform: rotate(" + degHours + "deg); transform: rotate(" + degHours + "deg);");
	}

	setInterval(getTime, 1000);
	getTime();

} ());});
</script>
';
	return $output;
}

vc_map( array(
	"name" => __("Clock",'orangeidea'),
	"base" => "vc_clock",
	"admin_enqueue_css" => array(get_template_directory_uri().'/framework/vc_extend/style.css'),
	"class" => "",
	"category" => __('BURAN','orangeidea'),
	"params" => array(
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"param_name" => "title",
			"heading" => __("Contact form title", "orangeidea"),
			"value" => '[contact-form-7]',
		),
		array(
			"type" => "textarea_html",
			"holder" => "div",
			"class" => "",
			"param_name" => "content",
			"heading" => __("content", "orangeidea"),
			"value" => '',
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"param_name" => "contact",
			"heading" => __("Contact form shortcode", "orangeidea"),
			"value" => '[contact-form-7]',
		)
	)
) );

?>